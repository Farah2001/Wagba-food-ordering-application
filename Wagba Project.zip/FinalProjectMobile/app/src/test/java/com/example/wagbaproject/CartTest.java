package com.example.wagbaproject;

import junit.framework.TestCase;

public class CartTest extends TestCase {

}