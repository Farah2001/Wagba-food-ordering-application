package com.example.wagbaproject;

public class MyUpdateCartEvent {
}
