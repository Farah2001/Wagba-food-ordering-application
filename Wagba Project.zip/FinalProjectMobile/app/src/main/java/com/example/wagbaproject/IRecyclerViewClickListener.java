package com.example.wagbaproject;

import android.view.View;

public interface IRecyclerViewClickListener {
    void onRecyclerClick(View view, int position);
}
