package com.example.wagbaproject;

public interface RecyclerViewInterface {
    void onitemclick(int position);
}
